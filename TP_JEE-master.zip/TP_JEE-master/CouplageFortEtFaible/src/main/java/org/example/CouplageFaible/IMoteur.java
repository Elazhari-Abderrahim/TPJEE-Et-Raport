package org.example.CouplageFaible;

public interface IMoteur {
    void demarrer();
}