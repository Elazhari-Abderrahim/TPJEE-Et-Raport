package org.example.CouplageFort;

public class Moteur {
    void demarrer(){
        System.out.println("Démerrer le moteur");
    }
}
