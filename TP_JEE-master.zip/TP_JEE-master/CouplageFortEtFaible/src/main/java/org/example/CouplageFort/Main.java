package org.example.CouplageFort;

public class Main {
    public static void main(String[] args) {
        Voiture v = new Voiture();
        v.bouger();
    }
}