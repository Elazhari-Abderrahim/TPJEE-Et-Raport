package org.example.CouplageFaible;

public interface IVoiture {
    void rouler();
}