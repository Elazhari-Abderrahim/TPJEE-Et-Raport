package annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnotationApplicationTests {

    @Test
    void contextLoads() {
    }

}
